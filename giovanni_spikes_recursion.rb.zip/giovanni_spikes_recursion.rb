def sum_to(n)
    return n if n == 1
    sum_to(n)
end